
# This file enforces the use of py-cord when import discord is used
import sys
import os

# Specify which version of discord is being used
__title__ = 'py-cord'
__version__ = '2.6.1'

# Print a message to confirm we're using py-cord
print("Using py-cord 2.6.1 (import override active)")
